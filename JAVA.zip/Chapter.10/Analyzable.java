public interface Analyzable{
    double getAve();
    GradedActivity getH();
    GradedActivity getL();
}