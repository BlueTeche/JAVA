public class area{

   static final double pi = Math.PI;

   static double area(double r){
	return pi*r*r;
   }

   static double area(int w, int l){
	return w*l;
   }

   static double area(double r, double h){
	return pi*r*r*h;
   }


}
