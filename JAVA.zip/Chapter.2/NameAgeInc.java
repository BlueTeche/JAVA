public class NameAgeInc{

    public static void main(String[] args){

	String fname,lname;
	int age;
	double annualPay;

	fname = "Minsun";
	lname = "Kim";
	age = 22;
	annualPay = 100000;

	System.out.println("My name is " + fname + " " + lname + ", my age is " + age + " and");
	System.out.println("I hope to earn " + annualPay + " per year");
    }

}