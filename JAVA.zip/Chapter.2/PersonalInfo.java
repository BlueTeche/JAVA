public class PersonalInfo{

    public static void main(String[] args){

	System.out.println("My name is Minsun Kim.\nMy home address is 43-24, 165th st, Flushing, NY 11358.\nMy phone number is 929-220-6958.\nMy major is Computer Science.");
    }

}