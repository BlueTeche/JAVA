public class MonthTest{
    public static void main(String[] args) throws Exception{
	Month ob = new Month("June");
	ob.setNum(13);
	System.out.println("Month: " + ob.toS());
	 
    }
}