public class WrongN extends Exception{
    public WrongN(){
	super("It should be between 1 and 12.");
    }
}

