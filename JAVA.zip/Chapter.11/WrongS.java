public class WrongS extends Exception{
    public WrongS(){
	super("Wrong. Please type the word.");
    }
}